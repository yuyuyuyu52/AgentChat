import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Bot, 
  Plus, 
  Search, 
  MoreVertical, 
  RefreshCw, 
  ExternalLink, 
  Key, 
  Activity,
  MessageSquare,
  ShieldAlert,
  Copy,
  CheckCircle2,
  AlertCircle,
  Clock
} from 'lucide-react';
import { 
  MOCK_AGENTS, 
  MOCK_CONVERSATIONS, 
  MOCK_AUDIT_LOGS,
  Agent 
} from '@/lib/mock-data';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogFooter
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'motion/react';

export default function Workspace() {
  const [agents, setAgents] = useState<Agent[]>(MOCK_AGENTS);
  const [searchQuery, setSearchQuery] = useState('');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newAgentName, setNewAgentName] = useState('');

  const filteredAgents = agents.filter(agent => 
    agent.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    agent.accountId.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleCreateAgent = () => {
    if (!newAgentName) return;
    
    const newAgent: Agent = {
      id: (agents.length + 1).toString(),
      name: newAgentName,
      accountId: `agent_${newAgentName.toLowerCase().replace(/\s+/g, '_')}_${Math.floor(Math.random() * 1000)}`,
      token: `ac_sk_${Math.random().toString(36).substring(2, 15)}`,
      status: 'offline',
      createdAt: new Date().toISOString(),
      lastActive: 'Never',
      owner: 'will29982@gmail.com'
    };

    setAgents([...agents, newAgent]);
    setNewAgentName('');
    setIsCreateModalOpen(false);
    toast.success('Agent created successfully', {
      description: `Identity: ${newAgent.accountId}`
    });
  };

  const handleResetToken = (id: string) => {
    setAgents(agents.map(a => 
      a.id === id ? { ...a, token: `ac_sk_${Math.random().toString(36).substring(2, 15)}` } : a
    ));
    toast.info('Token reset', {
      description: 'New security credentials have been issued.'
    });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard');
  };

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      {/* Main Controls */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground tracking-tight">Agent Console</h2>
          <p className="text-sm text-muted-foreground">Manage your autonomous workforce and issue credentials.</p>
        </div>
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="relative flex-1 md:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search agents..." 
              className="pl-10 bg-muted/50 border-border text-foreground placeholder:text-muted-foreground focus-visible:ring-blue-500"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700 text-white gap-2 rounded-lg">
                <Plus className="w-4 h-4" />
                Create Agent
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card border-border text-foreground">
              <DialogHeader>
                <DialogTitle>Create New Agent</DialogTitle>
                <DialogDescription className="text-muted-foreground">
                  Define a new identity for your autonomous agent.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Agent Display Name</Label>
                  <Input 
                    id="name" 
                    placeholder="e.g. Sales Assistant" 
                    className="bg-muted border-border"
                    value={newAgentName}
                    onChange={(e) => setNewAgentName(e.target.value)}
                  />
                </div>
                <div className="p-4 bg-blue-500/5 border border-blue-500/20 rounded-lg">
                  <p className="text-xs text-blue-500 leading-relaxed">
                    <AlertCircle className="w-3 h-3 inline mr-1" />
                    Creating an agent will automatically generate a unique Account ID and a secure API token.
                  </p>
                </div>
              </div>
              <DialogFooter>
                <Button variant="ghost" onClick={() => setIsCreateModalOpen(false)}>Cancel</Button>
                <Button className="bg-blue-600 hover:bg-blue-700 text-white" onClick={handleCreateAgent}>Initialize Agent</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>


      {/* Agent Table */}
      <Card className="bg-card border-border overflow-hidden">
        <Table>
          <TableHeader className="bg-muted/50">
            <TableRow className="border-border hover:bg-transparent">
              <TableHead className="text-[10px] uppercase tracking-widest font-bold text-muted-foreground">Agent Identity</TableHead>
              <TableHead className="text-[10px] uppercase tracking-widest font-bold text-muted-foreground">Status</TableHead>
              <TableHead className="text-[10px] uppercase tracking-widest font-bold text-muted-foreground">Credentials</TableHead>
              <TableHead className="text-[10px] uppercase tracking-widest font-bold text-muted-foreground">Last Active</TableHead>
              <TableHead className="text-right text-[10px] uppercase tracking-widest font-bold text-muted-foreground">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            <AnimatePresence mode="popLayout">
              {filteredAgents.map((agent) => (
                <motion.tr 
                  key={agent.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="border-border hover:bg-muted/50 transition-colors group"
                >
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <div className={cn(
                        "w-10 h-10 rounded-lg flex items-center justify-center border",
                        agent.status === 'online' ? "bg-green-500/10 border-green-500/20" : "bg-muted border-border"
                      )}>
                        <Bot className={cn("w-5 h-5", agent.status === 'online' ? "text-green-500" : "text-muted-foreground")} />
                      </div>
                      <div>
                        <p className="text-sm font-bold text-foreground leading-none mb-1">{agent.name}</p>
                        <p className="text-xs font-mono text-muted-foreground">{agent.accountId}</p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className={cn(
                      "rounded-full px-2 py-0 text-[10px] font-bold uppercase tracking-tighter",
                      agent.status === 'online' ? "bg-green-500/10 text-green-500 border-green-500/20" : "bg-muted text-muted-foreground border-border"
                    )}>
                      {agent.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <code className="text-xs font-mono text-muted-foreground bg-muted px-2 py-1 rounded border border-border">
                        {agent.token}
                      </code>
                      <Button 
                        size="icon" 
                        variant="ghost" 
                        className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={() => copyToClipboard(agent.token)}
                      >
                        <Copy className="w-3 h-3 text-muted-foreground" />
                      </Button>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Clock className="w-3 h-3" />
                      {agent.lastActive === 'Never' ? 'Never' : new Date(agent.lastActive).toLocaleTimeString()}
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Link to={`/app/agents/${agent.accountId}/conversations`}>
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="h-8 border-blue-500/20 hover:bg-blue-500/10 text-blue-500 text-xs font-bold"
                        >
                          <MessageSquare className="w-3 h-3 mr-2" />
                          Chats
                        </Button>
                      </Link>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="h-8 border-border hover:bg-muted text-xs font-bold"
                        onClick={() => handleResetToken(agent.id)}
                      >
                        <RefreshCw className="w-3 h-3 mr-2" />
                        Reset
                      </Button>
                      <Button size="icon" variant="ghost" className="h-8 w-8 text-muted-foreground">
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </motion.tr>
              ))}
            </AnimatePresence>
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}

