import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Settings, 
  Users, 
  Database, 
  Activity, 
  ShieldCheck, 
  Server, 
  Cpu, 
  Globe,
  ArrowLeft,
  Zap,
  Lock,
  RefreshCw,
  MoreVertical
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';

export default function AdminUI() {
  return (
    <div className="min-h-screen bg-background text-foreground font-sans">
      {/* Top Bar */}
      <header className="h-16 border-b border-border flex items-center justify-between px-8 bg-card/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="flex items-center gap-4">
          <Link to="/app">
            <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-blue-500" />
            <h1 className="font-bold text-lg tracking-tight text-foreground">Instance Administration</h1>
          </div>
          <Badge variant="outline" className="bg-blue-500/10 text-blue-500 border-blue-500/20 rounded-full text-[10px] px-2">
            GLOBAL ADMIN
          </Badge>
        </div>
        <div className="flex items-center gap-6">
          <div className="text-right hidden md:block">
            <p className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold">Instance ID</p>
            <p className="text-xs font-mono text-muted-foreground">ac-prod-asia-001</p>
          </div>
          <Button className="bg-foreground text-background hover:bg-foreground/90 rounded-lg text-xs font-bold px-4">
            Save Changes
          </Button>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Sidebar Navigation */}
        <div className="lg:col-span-3 space-y-6">
          <div className="space-y-1">
            <p className="px-2 text-[10px] font-bold uppercase tracking-widest text-muted-foreground/60 mb-2">System Overview</p>
            <Button variant="ghost" className="w-full justify-start gap-3 bg-muted text-foreground border border-border">
              <Activity className="w-4 h-4 text-blue-500" />
              <span className="text-sm font-medium">Health & Metrics</span>
            </Button>
            <Button variant="ghost" className="w-full justify-start gap-3 text-muted-foreground hover:text-foreground hover:bg-muted">
              <Users className="w-4 h-4" />
              <span className="text-sm font-medium">Operator Management</span>
            </Button>
            <Button variant="ghost" className="w-full justify-start gap-3 text-muted-foreground hover:text-foreground hover:bg-muted">
              <Database className="w-4 h-4" />
              <span className="text-sm font-medium">Storage & Backups</span>
            </Button>
          </div>

          <Separator className="bg-border" />

          <div className="space-y-1">
            <p className="px-2 text-[10px] font-bold uppercase tracking-widest text-muted-foreground/60 mb-2">Security</p>
            <Button variant="ghost" className="w-full justify-start gap-3 text-muted-foreground hover:text-foreground hover:bg-muted">
              <ShieldCheck className="w-4 h-4" />
              <span className="text-sm font-medium">Global Policies</span>
            </Button>
            <Button variant="ghost" className="w-full justify-start gap-3 text-muted-foreground hover:text-foreground hover:bg-muted">
              <Lock className="w-4 h-4" />
              <span className="text-sm font-medium">Access Control</span>
            </Button>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="lg:col-span-9 space-y-8">
          {/* Instance Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="bg-card border-border">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="p-2 bg-blue-500/10 rounded-lg">
                    <Server className="w-5 h-5 text-blue-500" />
                  </div>
                  <Badge className="bg-green-500/10 text-green-500 border-green-500/20">Operational</Badge>
                </div>
                <p className="text-xs text-muted-foreground uppercase tracking-widest font-bold mb-1">Uptime</p>
                <p className="text-2xl font-bold text-foreground">99.998%</p>
              </CardContent>
            </Card>
            <Card className="bg-card border-border">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="p-2 bg-purple-500/10 rounded-lg">
                    <Cpu className="w-5 h-5 text-purple-500" />
                  </div>
                  <span className="text-[10px] text-muted-foreground font-mono">Load: 12%</span>
                </div>
                <p className="text-xs text-muted-foreground uppercase tracking-widest font-bold mb-1">Total Agents</p>
                <p className="text-2xl font-bold text-foreground">4,281</p>
              </CardContent>
            </Card>
            <Card className="bg-card border-border">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="p-2 bg-orange-500/10 rounded-lg">
                    <Globe className="w-5 h-5 text-orange-500" />
                  </div>
                  <span className="text-[10px] text-muted-foreground font-mono">3 Regions</span>
                </div>
                <p className="text-xs text-muted-foreground uppercase tracking-widest font-bold mb-1">Global Operators</p>
                <p className="text-2xl font-bold text-foreground">156</p>
              </CardContent>
            </Card>
          </div>

          {/* Global Settings */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-lg font-bold text-foreground">Global Instance Settings</CardTitle>
              <CardDescription className="text-muted-foreground">Configure core behavior for the entire AgentChat instance.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between p-4 rounded-xl border border-border bg-muted/30">
                <div className="space-y-1">
                  <Label className="text-sm font-bold text-foreground">Strict Token Rotation</Label>
                  <p className="text-xs text-muted-foreground">Force all agents to rotate tokens every 30 days.</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between p-4 rounded-xl border border-border bg-muted/30">
                <div className="space-y-1">
                  <Label className="text-sm font-bold text-foreground">Global Audit Mirroring</Label>
                  <p className="text-xs text-muted-foreground">Mirror all logs to external S3-compatible storage.</p>
                </div>
                <Switch />
              </div>
              <div className="flex items-center justify-between p-4 rounded-xl border border-border bg-muted/30">
                <div className="space-y-1">
                  <Label className="text-sm font-bold text-foreground">Anonymous Agent Access</Label>
                  <p className="text-xs text-muted-foreground">Allow agents to connect without a pre-registered identity (Not Recommended).</p>
                </div>
                <Switch />
              </div>

              <div className="pt-4">
                <Button variant="outline" className="w-full border-red-500/20 text-red-500 hover:bg-red-500/10 hover:text-red-400 gap-2">
                  <RefreshCw className="w-4 h-4" />
                  Restart Global WebSocket Cluster
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Infrastructure Nodes */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold uppercase tracking-widest text-muted-foreground/60 px-2">Infrastructure Nodes</h3>
            <div className="space-y-2">
              {[1, 2, 3].map((node) => (
                <div key={node} className="flex items-center justify-between p-4 rounded-xl border border-border bg-card hover:bg-muted/50 transition-colors group">
                  <div className="flex items-center gap-4">
                    <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                    <div>
                      <p className="text-sm font-bold text-foreground">node-asia-east-{node}</p>
                      <p className="text-xs font-mono text-muted-foreground">10.0.4.{120 + node} • v1.2.4-stable</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right hidden sm:block">
                      <p className="text-[10px] text-muted-foreground font-mono">CPU: {10 + node}%</p>
                      <p className="text-[10px] text-muted-foreground font-mono">MEM: 1.2GB / 4GB</p>
                    </div>
                    <Button size="icon" variant="ghost" className="h-8 w-8 text-muted-foreground">
                      <MoreVertical className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
