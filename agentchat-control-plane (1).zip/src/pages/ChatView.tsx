import React, { useState, useEffect, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  ArrowLeft, 
  Send, 
  Bot, 
  User, 
  MoreVertical, 
  ShieldCheck,
  Clock,
  Terminal
} from 'lucide-react';
import { MOCK_CONVERSATIONS, MOCK_AGENTS, Message } from '@/lib/mock-data';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

export default function ChatView() {
  const { agentId, convId } = useParams();
  const conversation = MOCK_CONVERSATIONS.find(c => c.id === convId);
  const agent = MOCK_AGENTS.find(a => a.accountId === agentId);
  
  const [messages, setMessages] = useState<Message[]>(conversation?.messages || []);
  const [inputValue, setInputValue] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    const newMessage: Message = {
      id: `m${Date.now()}`,
      sender: 'operator',
      content: inputValue,
      timestamp: new Date().toISOString(),
      isAgent: false
    };

    setMessages([...messages, newMessage]);
    setInputValue('');
  };

  if (!conversation) return <div className="p-8 text-white">Conversation not found.</div>;

  return (
    <div className="flex flex-col h-full bg-background">
      {/* Chat Header */}
      <header className="h-16 border-b border-border flex items-center justify-between px-6 bg-card/50 backdrop-blur-md">
        <div className="flex items-center gap-4">
          <Link to={`/app/agents/${agentId}/conversations`}>
            <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-blue-500/10 border border-blue-500/20 flex items-center justify-center">
              <Bot className="w-5 h-5 text-blue-500" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-foreground">
                {conversation.participants.filter(p => p !== agentId).join(', ')}
              </h3>
              <div className="flex items-center gap-2">
                <span className="text-[10px] text-green-500 flex items-center gap-1">
                  <div className="w-1 h-1 rounded-full bg-green-500" />
                  Live Stream
                </span>
                <span className="text-[10px] text-muted-foreground font-mono">ID: {convId}</span>
              </div>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Badge variant="outline" className="bg-blue-500/10 text-blue-500 border-blue-500/20 text-[10px] uppercase font-bold tracking-tighter">
            {conversation.type}
          </Badge>
          <Button size="icon" variant="ghost" className="h-8 w-8 text-muted-foreground">
            <MoreVertical className="w-4 h-4" />
          </Button>
        </div>
      </header>

      {/* Messages Area */}
      <ScrollArea className="flex-1 p-6" viewportRef={scrollRef}>
        <div className="max-w-3xl mx-auto space-y-6">
          <div className="flex justify-center">
            <div className="px-3 py-1 bg-muted border border-border rounded-full text-[10px] text-muted-foreground uppercase tracking-widest font-bold">
              Conversation started on {new Date(conversation.timestamp).toLocaleDateString()}
            </div>
          </div>

          {messages.map((msg) => (
            <div 
              key={msg.id} 
              className={cn(
                "flex gap-4 group",
                msg.sender === 'operator' ? "flex-row-reverse" : "flex-row"
              )}
            >
              <div className={cn(
                "w-8 h-8 rounded-lg shrink-0 flex items-center justify-center border",
                msg.isAgent ? "bg-blue-500/10 border-blue-500/20" : "bg-muted border-border"
              )}>
                {msg.isAgent ? <Bot className="w-4 h-4 text-blue-500" /> : <User className="w-4 h-4 text-muted-foreground" />}
              </div>
              
              <div className={cn(
                "flex flex-col max-w-[80%]",
                msg.sender === 'operator' ? "items-end" : "items-start"
              )}>
                <div className="flex items-center gap-2 mb-1 px-1">
                  <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-tight">{msg.sender}</span>
                  <span className="text-[10px] text-muted-foreground/60 font-mono">{new Date(msg.timestamp).toLocaleTimeString()}</span>
                </div>
                <div className={cn(
                  "px-4 py-2 rounded-2xl text-sm leading-relaxed",
                  msg.sender === 'operator' 
                    ? "bg-blue-600 text-white rounded-tr-none shadow-lg shadow-blue-500/20" 
                    : "bg-muted text-foreground border border-border rounded-tl-none"
                )}>
                  {msg.content}
                </div>
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>

      {/* Message Input (Operator Intervention) */}
      <footer className="p-6 border-t border-border bg-card/50">
        <div className="max-w-3xl mx-auto">
          <div className="mb-4 flex items-center gap-2 px-3 py-2 bg-yellow-500/5 border border-yellow-500/10 rounded-lg">
            <ShieldCheck className="w-3 h-3 text-yellow-500" />
            <p className="text-[10px] text-yellow-600 dark:text-yellow-500/80 font-medium">
              OPERATOR MODE: Your messages will be sent as a manual intervention from <span className="font-bold">will29982@gmail.com</span>
            </p>
          </div>
          <form onSubmit={handleSendMessage} className="relative">
            <Input 
              placeholder="Type a message to intervene..." 
              className="pr-12 h-12 bg-muted/50 border-border text-foreground focus-visible:ring-blue-500 rounded-xl"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
            />
            <Button 
              type="submit"
              size="icon" 
              className="absolute right-1.5 top-1.5 h-9 w-9 bg-blue-600 hover:bg-blue-700 text-white rounded-lg"
              disabled={!inputValue.trim()}
            >
              <Send className="w-4 h-4" />
            </Button>
          </form>
          <div className="mt-3 flex items-center justify-between px-1">
            <div className="flex items-center gap-4">
              <button className="text-[10px] text-muted-foreground hover:text-foreground flex items-center gap-1 transition-colors">
                <Terminal className="w-3 h-3" />
                Raw Payload
              </button>
              <button className="text-[10px] text-muted-foreground hover:text-foreground flex items-center gap-1 transition-colors">
                <Clock className="w-3 h-3" />
                Schedule
              </button>
            </div>
            <span className="text-[10px] text-muted-foreground/60 font-mono">Press Enter to send</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
