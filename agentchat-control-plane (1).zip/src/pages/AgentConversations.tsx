import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  MessageSquare, 
  Users, 
  ChevronRight, 
  ArrowLeft,
  Clock,
  ExternalLink,
  Bot
} from 'lucide-react';
import { MOCK_CONVERSATIONS, MOCK_AGENTS } from '@/lib/mock-data';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export default function AgentConversations() {
  const { agentId } = useParams();
  const agent = MOCK_AGENTS.find(a => a.accountId === agentId);
  
  // Filter conversations where this agent is a participant
  const conversations = MOCK_CONVERSATIONS.filter(c => c.participants.includes(agentId || ''));

  return (
    <div className="p-8 space-y-8 max-w-5xl mx-auto">
      <div className="flex items-center gap-4">
        <Link to="/app/agents">
          <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-5 h-5" />
          </Button>
        </Link>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center">
            <Bot className="w-6 h-6 text-blue-500" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-foreground tracking-tight">{agent?.name || agentId}</h2>
            <p className="text-sm text-muted-foreground">Conversations & Message Streams</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {conversations.length > 0 ? (
          conversations.map((conv) => (
            <Link key={conv.id} to={`/app/agents/${agentId}/conversations/${conv.id}`}>
              <Card className="bg-card border-border hover:bg-muted/50 transition-all cursor-pointer group">
                <CardContent className="p-6 flex items-center gap-6">
                  <div className="w-12 h-12 rounded-full bg-blue-500/10 flex items-center justify-center border border-blue-500/20 group-hover:scale-110 transition-transform">
                    {conv.type === 'group' ? <Users className="w-6 h-6 text-blue-500" /> : <MessageSquare className="w-6 h-6 text-blue-500" />}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="text-lg font-bold text-foreground truncate">
                        {conv.participants.filter(p => p !== agentId).join(', ')}
                      </h3>
                      <Badge variant="outline" className="text-[10px] uppercase tracking-tighter bg-muted border-border text-muted-foreground">
                        {conv.type}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground truncate">{conv.lastMessage}</p>
                  </div>

                  <div className="text-right">
                    <div className="flex items-center justify-end gap-2 text-[10px] text-muted-foreground font-mono mb-2">
                      <Clock className="w-3 h-3" />
                      {new Date(conv.timestamp).toLocaleString()}
                    </div>
                    <div className="flex items-center justify-end gap-2">
                      {conv.unreadCount > 0 && (
                        <Badge className="bg-blue-600 text-white border-none h-5 px-1.5 min-w-[20px] flex items-center justify-center">
                          {conv.unreadCount}
                        </Badge>
                      )}
                      <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-blue-500 transition-colors" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))
        ) : (
          <div className="text-center py-20 border border-dashed border-border rounded-2xl">
            <MessageSquare className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">No active conversations found for this agent.</p>
          </div>
        )}
      </div>
    </div>
  );
}
