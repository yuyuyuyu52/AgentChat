import React from 'react';
import { 
  ShieldAlert, 
  Search, 
  Download, 
  Filter, 
  ChevronLeft, 
  ChevronRight,
  CheckCircle2,
  AlertCircle,
  Info,
  Clock,
  User,
  Bot
} from 'lucide-react';
import { MOCK_AUDIT_LOGS } from '@/lib/mock-data';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

export default function AuditLogs() {
  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground tracking-tight">Audit Infrastructure</h2>
          <p className="text-sm text-muted-foreground">Immutable record of all agent activities and operator interventions.</p>
        </div>
      </div>

      <Card className="bg-card border-border">
        <CardContent className="p-0">
          <Table>
            <TableHeader className="bg-muted/50">
              <TableRow className="border-border hover:bg-transparent">
                <TableHead className="text-[10px] uppercase tracking-widest font-bold text-muted-foreground">Timestamp</TableHead>
                <TableHead className="text-[10px] uppercase tracking-widest font-bold text-muted-foreground">Actor</TableHead>
                <TableHead className="text-[10px] uppercase tracking-widest font-bold text-muted-foreground">Action</TableHead>
                <TableHead className="text-[10px] uppercase tracking-widest font-bold text-muted-foreground">Target</TableHead>
                <TableHead className="text-[10px] uppercase tracking-widest font-bold text-muted-foreground">Status</TableHead>
                <TableHead className="text-[10px] uppercase tracking-widest font-bold text-muted-foreground">Details</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {MOCK_AUDIT_LOGS.map((log) => (
                <TableRow key={log.id} className="border-border hover:bg-muted/50 transition-colors group">
                  <TableCell className="text-xs font-mono text-muted-foreground">
                    {new Date(log.timestamp).toLocaleString()}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {log.actor.includes('@') ? (
                        <User className="w-3 h-3 text-blue-500" />
                      ) : (
                        <Bot className="w-3 h-3 text-purple-500" />
                      )}
                      <span className="text-xs font-mono text-foreground/80">{log.actor}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className="text-[10px] font-mono bg-muted border-border text-foreground/80">
                      {log.action}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-xs font-mono text-muted-foreground">
                    {log.target}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1.5">
                      {log.status === 'success' ? (
                        <CheckCircle2 className="w-3 h-3 text-green-500" />
                      ) : (
                        <AlertCircle className="w-3 h-3 text-red-500" />
                      )}
                      <span className={cn(
                        "text-[10px] font-bold uppercase tracking-tighter",
                        log.status === 'success' ? "text-green-500" : "text-red-500"
                      )}>
                        {log.status}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell className="max-w-xs">
                    <p className="text-xs text-muted-foreground truncate group-hover:whitespace-normal group-hover:overflow-visible transition-all">
                      {log.details}
                    </p>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
        <div className="px-6 py-4 border-t border-border flex items-center justify-between">
          <p className="text-xs text-muted-foreground">Showing 1-10 of 1,240 events</p>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" className="h-8 w-8 border-border bg-muted text-muted-foreground">
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="icon" className="h-8 w-8 border-border bg-muted text-muted-foreground">
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}

