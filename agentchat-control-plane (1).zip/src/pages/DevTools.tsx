import React from 'react';
import { 
  Terminal, 
  Copy, 
  Check, 
  Cpu, 
  Globe, 
  Package, 
  Code2,
  BookOpen
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { toast } from 'sonner';

export default function DevTools() {
  const [copiedIndex, setCopiedIndex] = React.useState<number | null>(null);

  const installCommands = [
    {
      label: 'Node.js SDK',
      command: 'npm install @agentchat/sdk',
      description: 'Official TypeScript/JavaScript SDK for agent integration.'
    },
    {
      label: 'Global CLI',
      command: 'curl -sSL https://agentchat.io/install.sh | sh',
      description: 'Command line interface for managing agents and deployments.'
    }
  ];

  const handleCopy = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    toast.success('Command copied to clipboard');
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <div className="p-8 space-y-8 max-w-4xl mx-auto">
      <div className="space-y-2">
        <h2 className="text-2xl font-bold text-foreground tracking-tight">Developer Tools</h2>
        <p className="text-sm text-muted-foreground">Integrate AgentChat into your existing infrastructure using our SDK and CLI.</p>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {installCommands.map((item, index) => (
          <Card key={index} className="bg-card border-border overflow-hidden">
            <CardHeader className="pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center">
                  {index === 0 ? <Package className="w-5 h-5 text-blue-500" /> : <Terminal className="w-5 h-5 text-blue-500" />}
                </div>
                <div>
                  <CardTitle className="text-lg font-bold text-foreground">{item.label}</CardTitle>
                  <CardDescription className="text-muted-foreground">{item.description}</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="relative group">
                <div className="flex items-center justify-between p-4 bg-muted/50 border border-border rounded-xl font-mono text-sm text-blue-600 dark:text-blue-400">
                  <span className="truncate mr-12">$ {item.command}</span>
                  <Button 
                    size="icon" 
                    variant="ghost" 
                    className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8 text-muted-foreground hover:text-foreground hover:bg-muted"
                    onClick={() => handleCopy(item.command, index)}
                  >
                    {copiedIndex === index ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
