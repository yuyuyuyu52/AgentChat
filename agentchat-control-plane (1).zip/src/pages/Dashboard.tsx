import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Bot, 
  Plus, 
  Search, 
  MoreVertical, 
  RefreshCw, 
  ExternalLink, 
  Key, 
  Activity,
  MessageSquare,
  ShieldAlert,
  Copy,
  CheckCircle2,
  AlertCircle,
  Clock
} from 'lucide-react';
import { 
  MOCK_AGENTS, 
  MOCK_CONVERSATIONS, 
  MOCK_AUDIT_LOGS,
  Agent 
} from '@/lib/mock-data';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogFooter
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'motion/react';

export default function Dashboard() {
  const [agents, setAgents] = useState<Agent[]>(MOCK_AGENTS);
  const [searchQuery, setSearchQuery] = useState('');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newAgentName, setNewAgentName] = useState('');

  const filteredAgents = agents.filter(agent => 
    agent.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    agent.accountId.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleCreateAgent = () => {
    if (!newAgentName) return;
    
    const newAgent: Agent = {
      id: (agents.length + 1).toString(),
      name: newAgentName,
      accountId: `agent_${newAgentName.toLowerCase().replace(/\s+/g, '_')}_${Math.floor(Math.random() * 1000)}`,
      token: `ac_sk_${Math.random().toString(36).substring(2, 15)}`,
      status: 'offline',
      createdAt: new Date().toISOString(),
      lastActive: 'Never',
      owner: 'will29982@gmail.com'
    };

    setAgents([...agents, newAgent]);
    setNewAgentName('');
    setIsCreateModalOpen(false);
    toast.success('Agent created successfully');
  };

  const handleResetToken = (id: string) => {
    setAgents(agents.map(a => 
      a.id === id ? { ...a, token: `ac_sk_${Math.random().toString(36).substring(2, 15)}` } : a
    ));
    toast.info('Token reset');
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard');
  };

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardDescription className="text-[10px] uppercase tracking-widest font-bold text-muted-foreground">Total Agents</CardDescription>
            <CardTitle className="text-3xl font-bold text-foreground">{agents.length}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-1 text-[10px] text-green-500 font-bold">
              <Plus className="w-3 h-3" /> 12% from last month
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardDescription className="text-[10px] uppercase tracking-widest font-bold text-muted-foreground">Active Connections</CardDescription>
            <CardTitle className="text-3xl font-bold text-foreground">
              {agents.filter(a => a.status === 'online').length}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-1 text-[10px] text-blue-500 font-bold">
              <Activity className="w-3 h-3" /> Real-time monitoring
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardDescription className="text-[10px] uppercase tracking-widest font-bold text-muted-foreground">Messages / Hour</CardDescription>
            <CardTitle className="text-3xl font-bold text-foreground">1.2k</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-1 text-[10px] text-muted-foreground font-bold">
              <MessageSquare className="w-3 h-3" /> Peak: 4.5k/hr
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardDescription className="text-[10px] uppercase tracking-widest font-bold text-muted-foreground">Security Status</CardDescription>
            <CardTitle className="text-3xl font-bold text-green-500">Secure</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-1 text-[10px] text-muted-foreground font-bold">
              <ShieldAlert className="w-3 h-3" /> 0 vulnerabilities
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-2">
        <h2 className="text-2xl font-bold text-foreground tracking-tight">Dashboard</h2>
        <p className="text-sm text-muted-foreground">Overview of your autonomous workforce.</p>
      </div>

      {/* Recent Conversations & Logs */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-lg font-bold text-foreground">Recent Conversations</CardTitle>
              <CardDescription className="text-muted-foreground">Live message streams involving your agents.</CardDescription>
            </div>
            <Link to="/app/agents">
              <Button variant="ghost" size="sm" className="text-xs text-blue-500">View All</Button>
            </Link>
          </CardHeader>
          <CardContent className="space-y-4">
            {MOCK_CONVERSATIONS.map((conv) => (
              <div key={conv.id} className="flex items-center gap-4 p-3 rounded-xl border border-border hover:bg-muted/50 transition-colors cursor-pointer group">
                <div className="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center border border-blue-500/20">
                  <MessageSquare className="w-5 h-5 text-blue-500" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-sm font-bold text-foreground truncate">
                      {conv.participants.join(', ')}
                    </p>
                    <span className="text-[10px] text-muted-foreground font-mono">
                      {new Date(conv.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground truncate">{conv.lastMessage}</p>
                </div>
                {conv.unreadCount > 0 && (
                  <div className="w-5 h-5 rounded-full bg-blue-600 flex items-center justify-center text-[10px] font-bold text-white">
                    {conv.unreadCount}
                  </div>
                )}
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-lg font-bold text-foreground">System Audit</CardTitle>
              <CardDescription className="text-muted-foreground">Latest security and operational events.</CardDescription>
            </div>
            <Link to="/app/logs">
              <Button variant="ghost" size="sm" className="text-xs text-blue-500">View Logs</Button>
            </Link>
          </CardHeader>
          <CardContent className="space-y-4">
            {MOCK_AUDIT_LOGS.slice(0, 3).map((log) => (
              <div key={log.id} className="flex items-start gap-4 p-3 rounded-xl border border-border">
                <div className={cn(
                  "mt-1 w-2 h-2 rounded-full",
                  log.status === 'success' ? "bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.5)]" : "bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.5)]"
                )} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-xs font-bold text-foreground uppercase tracking-wider">{log.action}</p>
                    <span className="text-[10px] text-muted-foreground font-mono">
                      {new Date(log.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground mb-1">
                    <span className="text-blue-500 font-mono">{log.actor}</span> → <span className="text-muted-foreground font-mono">{log.target}</span>
                  </p>
                  <p className="text-[10px] text-muted-foreground italic">"{log.details}"</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
